#use of .format and f string formatting for print

variable1="manish"
variable2="raj"



print(f"my first name is  {variable1}  and my last name is {variable2}")