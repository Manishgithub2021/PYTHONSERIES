import keyword

mylist=(keyword.kwlist)
print(mylist)
print(len(mylist))


#len is used to find length
