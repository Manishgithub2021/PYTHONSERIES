file1=open("mytext.txt","w")
print("I AM WRITING ALL THIS IN mytext file during teaching and i love drawing",file=file1)
file1.close()



#in this example sep and end are by default, we are not setting anything
#to open a file in write mode fp=open("mytext.txt","w")
#if file is not present in current directory, it will make a file with same name for you
#But it is good to use try except block to catch any exception occurs during this operation