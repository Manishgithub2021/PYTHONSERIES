#print(objects,sep="",end="\n",file=file)
variable1="EGG"
variable2='FISH'
#by default printing in new line
print("HELLO")
print("WORLD")
#by default sep will be single space
print(variable1,variable2)

#using our own separator instead of by default space
print("I EAT ",variable1,variable2,sep="  ----->  ")

print("I EAT ",variable1,variable2,sep=" $$$$$$$   ")

#using our own end in place of by default \n or new line
print(variable1,end="             ")
print("HELLOWORLD")
