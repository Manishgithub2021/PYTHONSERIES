rollno=5
rollno1=6
print(rollno,rollno1)
print("HELLO WORLD")

#here hello world is printed on next line because by default end=\n which means new line
# two variables rollno and rollno1 are separated by single space because sep is single space by default