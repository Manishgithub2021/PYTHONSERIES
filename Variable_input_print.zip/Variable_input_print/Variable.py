# THROUGH THE # SYMBOL WE CAN COMMENT OUT THE PYTHON CERTAIN CODE/STATEMENT
#RULES OF DEFINING A VARIABLE
# 1. IT MUST START WITH _ OR ALPHABTET(A-Z or a-z)
# 2. After this number/digit can be used any where
#first alphabet should be small letter that indicates variable.
# my_first_name , this type of underscore between the words is also a good naming convention

name1="PANKAJ"
name2="RAJ"
#PRINTING TWO VARIABLE IN A SINGLE PRINT
print(name1,name2)

rollno=5
#Printing a single variable at a time
print(rollno)
#MULTIPLE ASSIGNMET IN A SINGLE LINE
a=b=c=d=e=5
print(a,b,c,d,e)
#THIS CODE SHOWS THAT ALL IDS ARE SHAME IF ALL HAVING SAME VALUES
print(id(a))
print(id(b))
print(id(c))

myname="Manish"
yourname="RAJA"
print(myname,yourname)
#a,b=b,a
myname,yourname=yourname,myname
print(myname,yourname)