x=input()
print(x)
#type is used to check what data type is this
print(type(x))
#type casting string to int in a single line
y=int(input())
print(type(y))
print(y)
z=input("ENTER Z VALUE")
print(z)

